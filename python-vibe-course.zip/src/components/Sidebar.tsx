// src/components/Sidebar.tsx
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCompletion } from "@/hooks/useCompletion"; // Import the hook
import { CheckCircle } from "lucide-react"; // Import an icon for completion

// Define the course structure (can be moved to a separate config file later)
const courseStructure = [
  {
    title: "Introduction",
    slug: "introduction",
    lessons: [
      { title: "What is Python?", slug: "01_python_overview" },
      { title: "What is Vibe Coding?", slug: "02_vibe_coding_definition" },
      { title: "AI Benefits & Limits", slug: "03_ai_benefits_limits" },
    ],
  },
  {
    title: "Environment Setup",
    slug: "environment_setup",
    lessons: [
      { title: "Installing Python", slug: "01_installing_python" },
      { title: "Setting Up VS Code", slug: "02_setting_up_vscode" },
      { title: "Installing AI Assistant", slug: "03_installing_ai_assistant" },
    ],
  },
  {
    title: "Python Basics",
    slug: "python_basics",
    lessons: [
      { title: "Variables & Data Types", slug: "01_variables_datatypes" },
      { title: "Operators", slug: "02_operators" },
      { title: "Control Structures", slug: "03_control_structures" },
      { title: "Functions & Modules", slug: "04_functions_modules" },
    ],
  },
  {
    title: "Intermediate Python",
    slug: "intermediate_python",
    lessons: [
      { title: "OOP: Classes & Objects", slug: "01_oop_classes_objects" },
      { title: "OOP: Inheritance & Encapsulation", slug: "02_oop_inheritance_encapsulation" },
      { title: "Data Structures", slug: "03_data_structures" },
      { title: "File Handling", slug: "04_file_handling" },
    ],
  },
  {
    title: "Advanced Python",
    slug: "advanced_python",
    lessons: [
      { title: "Decorators & Generators", slug: "01_decorators_generators" },
      { title: "Async Programming", slug: "02_async_programming" },
      { title: "Working with APIs", slug: "03_api_calls" },
      { title: "Frameworks & Libraries", slug: "04_frameworks_libs" },
    ],
  },
  {
    title: "Vibe Coding with AI",
    slug: "vibe_coding_ai",
    lessons: [
      { title: "AI Autocompletion", slug: "01_ai_autocompletion" },
      { title: "Generating Snippets", slug: "02_generating_snippets" },
      { title: "Debugging & Explanation", slug: "03_debugging_assistance" },
      { title: "Algorithm Design", slug: "04_algorithm_design" },
    ],
  },
  {
    title: "Main Project: Weather App",
    slug: "main_project_weather_app",
    lessons: [
      { title: "Intro & API Setup", slug: "01_project_intro_api" },
      { title: "Manual Walkthrough", slug: "02_manual_walkthrough" },
      { title: "AI-Assisted Walkthrough", slug: "03_ai_assisted_walkthrough" },
      { title: "(Optional) Visualization", slug: "04_optional_visualization" },
    ],
  },
  {
    title: "Mini-Projects",
    slug: "mini_projects",
    lessons: [
      { title: "Flask Weather Web App", slug: "01_flask_weather_app" },
      { title: "Pandas Weather Analysis", slug: "02_pandas_analysis" },
    ],
  },
   {
    title: "Best Practices & Ethics",
    slug: "best_practices_ethics",
    lessons: [
      { title: "Balancing AI & Manual", slug: "01_balancing_ai_manual" },
      { title: "Understanding & Ethics", slug: "02_understanding_ethics" },
    ],
  },
  {
    title: "Assessments",
    slug: "assessments_quizzes",
    lessons: [
        { title: "Quizzes", slug: "01_quizzes_overview" },
    ]
  },
  {
    title: "Resources",
    slug: "resources",
    lessons: [
        { title: "Further Learning", slug: "01_further_learning" },
    ]
  }
];

export default function Sidebar() {
  const pathname = usePathname();
  const { isLessonComplete } = useCompletion(); // Use the hook

  return (
    <aside className="w-64 lg:w-72 bg-sidebar text-sidebar-foreground border-r border-sidebar-border flex flex-col">
      <div className="p-4 border-b border-sidebar-border">
        <Link href="/" className="text-xl font-semibold text-sidebar-primary hover:text-sidebar-primary/80">
          Python Vibe Coding
        </Link>
      </div>
      <nav className="flex-1 overflow-y-auto p-4 space-y-4">
        {courseStructure.map((module) => (
          <div key={module.slug}>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              {module.title}
            </h3>
            <ul className="space-y-1">
              {module.lessons.map((lesson) => {
                const lessonId = `${module.slug}/${lesson.slug}`; // Unique ID for completion tracking
                const href = `/course/${lessonId}`;
                const isActive = pathname === href;
                const isComplete = isLessonComplete(lessonId);

                return (
                  <li key={lesson.slug}>
                    <Link
                      href={href}
                      className={`
                        flex items-center justify-between px-3 py-1.5 rounded-md text-sm 
                        transition-colors duration-150 
                        ${isActive
                          ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                          : isComplete 
                          ? "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground" // Style for completed, non-active
                          : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground" // Style for incomplete, non-active
                        }
                      `}
                    >
                      <span>{lesson.title}</span>
                      {isComplete && (
                        <CheckCircle className="h-4 w-4 text-green-500" /> // Show checkmark if complete
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}

