// src/app/course/[module_slug]/[lesson_slug]/page.tsx
import fs from "fs";
import path from "path";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { notFound } from "next/navigation";

import CompletionButton from "@/components/CompletionButton"; // Import the button
import Discussion from "@/components/Discussion"; // Import the discussion component

// Define the expected params structure
interface LessonPageProps {
  params: {
    module_slug: string;
    lesson_slug: string;
  };
}

// Function to get lesson content
async function getLessonContent(moduleSlug: string, lessonSlug: string): Promise<string | null> {
  // Construct the path relative to the project root
  // Note: Adjust the base path if your content directory is elsewhere or structure differs
  const contentBasePath = path.join(process.cwd(), "course_content");
  
  // Map URL slugs to directory/file names (assuming they match, otherwise needs mapping)
  // Example: module_slug "python_basics" -> directory "03_python_basics"
  // Example: lesson_slug "01_variables_datatypes" -> file "01_variables_datatypes.md"
  
  // Find the corresponding module directory name (e.g., "01_introduction" for "introduction")
  // This requires knowing the mapping or reading the directory structure.
  // For simplicity, let's assume a direct mapping or find it dynamically (more complex).
  // We'll hardcode the mapping based on the Sidebar structure for now.
  const moduleMap: { [key: string]: string } = {
    "introduction": "01_introduction",
    "environment_setup": "02_environment_setup",
    "python_basics": "03_python_basics",
    "intermediate_python": "04_intermediate_python",
    "advanced_python": "05_advanced_python",
    "vibe_coding_ai": "06_vibe_coding_ai",
    "main_project_weather_app": "07_main_project_weather_app",
    "mini_projects": "08_mini_projects",
    "best_practices_ethics": "09_best_practices_ethics",
    "assessments_quizzes": "10_assessments_quizzes",
    "resources": "11_resources",
  };

  const moduleDirName = moduleMap[moduleSlug];
  if (!moduleDirName) {
    console.error(`Module directory not found for slug: ${moduleSlug}`);
    return null; // Module slug doesn't map to a known directory
  }

  const filePath = path.join(contentBasePath, moduleDirName, `${lessonSlug}.md`);

  try {
    // Read the markdown file content
    const fileContent = fs.readFileSync(filePath, "utf-8");
    return fileContent;
  } catch (error) {
    // Handle file not found or other reading errors
    console.error(`Error reading file: ${filePath}`, error);
    return null;
  }
}

// The Page component
export default async function LessonPage({ params }: LessonPageProps) {
  const { module_slug, lesson_slug } = params;
  const markdownContent = await getLessonContent(module_slug, lesson_slug);

  if (!markdownContent) {
    // If content is not found, render the Next.js 404 page
    notFound();
  }

  return (
    <article className="prose prose-invert max-w-none 
                      prose-headings:text-primary prose-a:text-secondary hover:prose-a:text-secondary/80 
                      prose-strong:text-foreground prose-code:text-accent-foreground prose-code:bg-accent 
                      prose-pre:bg-accent prose-pre:text-accent-foreground 
                      prose-blockquote:border-primary prose-blockquote:text-muted-foreground">
      {/* Render the markdown content */}
      <ReactMarkdown remarkPlugins={[remarkGfm]}>
        {markdownContent}
      </ReactMarkdown>
      {/* Add the completion button */}
      <CompletionButton lessonId={`${module_slug}/${lesson_slug}`} />
      {/* Add the discussion section */}
      <Discussion />
    </article>
  );
}

// Optional: Generate static paths if you want to pre-render pages at build time
// export async function generateStaticParams() {
//   // Read the course structure (similar to Sidebar) and generate paths
//   // Example: return [{ module_slug: 'introduction', lesson_slug: '01_python_overview' }, ...]
//   // This requires reading the file system or having the structure available here.
//   return []; // Return empty array if not using static generation for lessons
// }

